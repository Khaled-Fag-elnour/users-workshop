export const environment = {
  production: true,
  api_url_prefix: `https://reqres.in/api`
};
